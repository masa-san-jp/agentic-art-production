# Elements — Creative direction

## 作品の核

PH001「Open Revision Wall」: A shared image stays open when each visitor may revise one mark and the earlier marks remain visible.

核の問い: Who decides when a shared image is finished?

## 継承する美的傾向

素材と振る舞い: Water-based ink on paper that fades under the gallery light over the exhibition weeks.

構成要素: A large paper wall with a printed grid、A stamp kit with one ink color per day、A logbook where each change is dated

## 意図的に破る傾向

The idea that a shared work must end in one final composition.

飛躍: The work turns revision itself into the subject by keeping every overwritten mark legible.

## 必須制約

- RQ001（experience）: Within three minutes a visitor must see at least two layers of revision on one square.
- RQ002（material）: The ink must remain legible after two weeks under gallery light.
- RQ003（interaction）: Every visitor must be able to redraw one square without staff help.
- RQ004（mechanism）: Each day of revision must be readable from its ink color and logbook date.

仕掛け（CEASES_TO_WORK）: Each day uses a new ink color and the logbook dates it, so the order of every revision can be read from the wall itself.

## 完了経路

1. Print the grid on a roll of paper and mount it on the wall.
2. Prepare the stamp kit and the dated logbook beside the wall.
3. Run a one-day trial with ten visitors and record every change.

## 未解決事項

対立したままの主張の組 1 件。調査の下限に届かない項目: self_repetition_review。試作と鑑賞者による確認は未実施（調査の不確実性 2 件が OPEN）。

## 比較した別の案

- PH002「Locked Frame Archive」: An image locked at opening shows what a collective loses when a final choice closes revision.

PH001「Open Revision Wall」を推薦する。根拠の厚さ 3/5 と実現性 3/5 の合計が最も高い（同点なら番号の若い案）。
